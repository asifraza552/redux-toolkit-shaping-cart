import { configureStore } from '@reduxjs/toolkit';
import casrtSlice from '../cartSlice/Index';

export default configureStore({
    reducer: {
        cart: casrtSlice
    },
});