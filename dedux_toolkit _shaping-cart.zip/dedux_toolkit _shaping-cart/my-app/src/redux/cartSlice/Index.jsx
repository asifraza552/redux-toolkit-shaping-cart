import { createSlice } from '@reduxjs/toolkit'
export const casrtSlice = createSlice({
    name: 'cart',
    initialState: {
        items: [],
        totalprice: 0
    },
    reducers: {
        addtocart: (state, action) => {
            const newitem = action.payload;
            state.items.push(newitem);
            state.totalprice += newitem.price
        },
        clearcart: (state) => {
            state.items = [],
                state.totalprice = 0
        }
    }
})
export const selectcartitems = (state) => state.cart.items
export const selectcarttotalprice = (state) => state.cart.totalprice
export const { addtocart, clearcart } = casrtSlice.actions
export default casrtSlice.reducer