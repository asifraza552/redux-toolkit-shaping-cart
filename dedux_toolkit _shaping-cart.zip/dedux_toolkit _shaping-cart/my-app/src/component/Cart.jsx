import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { clearcart, selectcartitems } from '../redux/cartSlice/Index';
import { Link } from 'react-router-dom';
import { ToastContainer, toast, Bounce } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Cart() {
  const dispatch = useDispatch()
  const cartitem = useSelector(selectcartitems)
  console.log("cart items", selectcartitems)

  return (
    <>
      <ToastContainer />
      <div className="container text-center" style={{ width: "700px" }}>
        {
          cartitem.length == 0 && (
            <>
              <h2>your cart is impty</h2>
              <Link to={"/"} className="btn btn-warning">canty new shaping</Link>
            </>
          )
        }
        {
          cartitem.map((item) => (
            <div key={item.id} className="container my-5">
              <div className="card mb-3 bg-dark text-light text-center" style={{ width: "650px" }}>
                <div className="row g-0">
                  <div className="col-md-4">
                    <div className='p-4'>
                      <img src={item.imgSrc} className="img-fluid rounded-start" style={{
                        borderRadius: "10px",
                      }} />
                    </div>
                  </div>
                  <div className="col-md-8">
                    <div className="card-body">
                      <h5 className="card-title mt-4">{item.title}</h5>
                      <p className="card-text">{item.title}</p>
                      <button className="btn btn-primary mx-3">{item.price}</button>
                      <button className="btn btn-warning">bay now</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        {
          cartitem.length != 0 && (
            <button onClick={() => {
              dispatch(clearcart())
              toast.success('🦄 cart cleare', {
                position: "top-right",
                autoClose: 1500,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
                transition: Bounce,
              });
            }}
              className="btn btn-warning mt-2"><h3>Clearcart</h3></button>
          )}
      </div>
    </>
  )
}
export default Cart
