import './App.css'
import Cart from './component/Cart'
import Navbar from './component/Navbar'
import Product from './component/Product'
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {

  return (
   <>
   <BrowserRouter>
   <Navbar/>
   <Routes>
   <Route path='/' element={<Product/>} />
   <Route path='/cart' element={<Cart/>} />
   {/* <Route path="/" element={<Blogs />} /> */}
   </Routes>
   </BrowserRouter>
   </>
  )
}

export default App
